import UIKit
import Kingfisher
class MusicCell: UITableViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var labelTrackName: UILabel!
    @IBOutlet weak var labelArtist: UILabel!
    @IBOutlet weak var labelRelease: UILabel!
    @IBOutlet weak var labelTrackPrice: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    // MARK: - Music data to assign Label 
    var music:Music?{
        didSet{
            labelTrackName.text = music?.trackCensoredName
            labelArtist.text = music?.artistName
            labelRelease.text = music?.releaseDate?.toString()
            labelTrackPrice.text = MusicField.dollar + (music?.trackPrice)!
            let urlImg = ImageResource(downloadURL: URL(string: (music?.artworkUrl100)!)!, cacheKey: music?.artworkUrl100)
            imgView.kf.setImage(with: urlImg)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
extension Date {
    func string(with format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
}
