//
//  DetailViewController.swift
//  iTuneCoreData
//
//  Created by SOTSYS027 on 21/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import Kingfisher
class DetailViewController: UITableViewController {

    // MARK: - Outlets
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblTrackName: UILabel!
    @IBOutlet weak var lblArtistName: UILabel!
    @IBOutlet weak var lblCollectionName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblGenre: UILabel!
    @IBOutlet weak var lblReleaseDate: UILabel!
    var music:Music?
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        let urlImage = ImageResource(downloadURL: URL(string: (music?.artworkUrl100)!)!, cacheKey: music?.artworkUrl100)
        imgView.kf.setImage(with: urlImage)
        lblTrackName.text = music?.trackCensoredName
        lblArtistName.text = music?.artistName
        lblCollectionName.text = music?.collectionName
        lblGenre.text = music?.primaryGenreName
        lblPrice.text = MusicField.dollar + (music?.trackPrice)!
        lblReleaseDate.text = music?.releaseDate?.toString()
    }
    
    // MARK: - TableView Delegate and Datasource Methods
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 44 : 44
    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 40))
               headerView.backgroundColor = UIColor.groupTableViewBackground
            return headerView
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 1{
              if indexPath.row == 1{
                 let albumDetailVC = self.storyboard?.instantiateViewController(withIdentifier: Identifier.albumDetailVC) as! AlbumDetailViewController
                albumDetailVC.music = music
                 self.navigationController?.pushViewController(albumDetailVC, animated: true)
            }
        }
    }
}
