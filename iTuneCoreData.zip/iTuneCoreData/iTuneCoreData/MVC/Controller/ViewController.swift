
import UIKit
import CoreData
import SwiftyJSON
import Kingfisher
class ViewController: UIViewController  {
    
    // MARK: - Outlets
    @IBOutlet weak var searchController: UISearchBar!
    var dict = [String:JSON]()
    let height:CGFloat = 124
    var isSearch:Bool = false
    var music:[Music] = []
    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - UIView Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        music = DatabaseManaeger.sharedInstance.getAllData()
        globalJsonData()
        self.tableView.tableFooterView = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        searchController.text = nil
        music = DatabaseManaeger.sharedInstance.getAllData()
        globalJsonData()
        self.tableView.reloadData()
    }
    
    // MARK: - JSON Data
    func globalJsonData(){
        if Rechability.isConnectedToNetwork(){
            let str = baseUrl + searchUrl
            let strUrl = str.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
            let url = URL(string: strUrl!)
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                if let data = data {
                    do{
                        let json = try JSON(data:data)
                        let data = json["results"].arrayValue
                        for arr in data{
                            DatabaseManaeger.sharedInstance.save(json: arr.dictionaryValue)
                        }
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    }catch{
                        print(errTitle.json)
                    }
                }
            }.resume()
        } else {
            DispatchQueue.main.async {
                self.tableView.reloadData()
           }
       }
    }
}

// MARK: - UITableView Delegate and Datasource Methods
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if Rechability.isConnectedToNetwork(){
            return music.count
        }else{
            return music.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Identifier.musicCell, for: indexPath) as! MusicCell
        if Rechability.isConnectedToNetwork(){
            cell.music = music[indexPath.row]
        }else{
            cell.music = music[indexPath.row]
      }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return height
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: Identifier.detailVC) as! DetailViewController
        if Rechability.isConnectedToNetwork(){
            detailVC.music = music[indexPath.row]
       }else{
            detailVC.music = music[indexPath.row]
        }
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
}

// MARK: - SearchDelegate Methods
extension ViewController: UISearchBarDelegate{
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSearch = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSearch = false
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearch = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        isSearch = false
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText == ""{
            isSearch = false
        }else{
            isSearch = true
        }
        globalJsonData()
        if Rechability.isConnectedToNetwork(){
           searchUrl = searchText
           music = DatabaseManaeger.sharedInstance.filterMusicData(name: searchText)
        }else{
            music = DatabaseManaeger.sharedInstance.filterMusicData(name: searchText)
        }
        tableView.reloadData()
   }
}



