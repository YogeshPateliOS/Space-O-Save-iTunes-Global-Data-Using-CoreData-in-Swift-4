//
//  AlbumDetailViewController.swift
//  iTuneCoreData
//
//  Created by SOTSYS027 on 21/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import Kingfisher
class AlbumDetailViewController: UITableViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblCollectionName: UILabel!
    @IBOutlet weak var lblArtistName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblTrackCount: UILabel!
    @IBOutlet weak var lblCountry: UILabel!
    @IBOutlet weak var lblReleaseDate: UILabel!
    @IBOutlet weak var lblYear: UILabel!
    @IBOutlet weak var iconImage: UIImageView!
    var music:Music?
    
    //MARK: - UIView LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        let urlImage = ImageResource(downloadURL: URL(string: (music?.artworkUrl100)!)!, cacheKey: music?.artworkUrl100)
        imgView.kf.setImage(with: urlImage)
        lblCollectionName.text = music?.collectionName
        lblArtistName.text = music?.artistName
        lblPrice.text = MusicField.dollar + (music?.trackPrice)!
        lblTrackCount.text = music?.trackCount
        lblCountry.text = music?.country
        lblReleaseDate.text = music?.releaseDate?.toString()
        lblYear.text = music?.releaseDate?.getYear()
        iconImage.tintColor = .black
    }
    
    // MARK: - TableView Delegate and Datasource Methods
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 44 : 44
    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 40))
        headerView.backgroundColor = UIColor.groupTableViewBackground
        return headerView
    }
}
