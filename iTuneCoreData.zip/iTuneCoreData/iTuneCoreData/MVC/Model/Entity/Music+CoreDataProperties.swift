//
//  Music+CoreDataProperties.swift
//  iTuneCoreData
//
//  Created by SOTSYS027 on 19/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//
//

import Foundation
import CoreData


extension Music {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Music> {
        return NSFetchRequest<Music>(entityName: "Music")
    }

    @NSManaged public var trackCensoredName: String?
    @NSManaged public var artistName: String?
    @NSManaged public var releaseDate: String?
    @NSManaged public var trackPrice: String?
    @NSManaged public var artworkUrl100: String?
    @NSManaged public var musicID: String?
    @NSManaged public var collectionName: String?
    @NSManaged public var primaryGenreName: String?
    @NSManaged public var country: String?
    @NSManaged public var trackCount: String?
    
}
