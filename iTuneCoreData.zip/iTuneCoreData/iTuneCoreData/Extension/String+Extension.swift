//
//  String+Extension.swift
//  iTuneCoreData
//
//  Created by SOTSYS027 on 21/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation

extension String{
    
    // MARK: - get date
    func toString() -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        let yourDate = formatter.date(from: self)
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter.string(from: yourDate!)
    }
    
    // MARK: - get year form date
    func getYear() -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        let yourDate = formatter.date(from: self)
        formatter.dateFormat = "yyyy"
        return formatter.string(from: yourDate!)
    }
    
}

