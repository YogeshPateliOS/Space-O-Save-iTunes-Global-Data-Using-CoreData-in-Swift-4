import Foundation

// MARK: - urls
var urlString = "https://itunes.apple.com/search?media=music&term=bollywood"
var searchUrl = ""
var baseUrl = "https://itunes.apple.com/search?media=music&term="

// MARK: - Music Field Names
struct MusicField{
    static let trackCensoredName = "trackCensoredName"
    static let artistName = "artistName"
    static let releaseDate = "releaseDate"
    static let trackPrice = "trackPrice"
    static let artworkUrl100 = "artworkUrl100"
    static let artistId = "artistId"
    static let music = "Music"
    static let results = "results"
    static let primaryGenreName = "primaryGenreName"
    static let collectionName = "collectionName"
    static let dollar = "$"
    static let country = "country"
    static let trackCount = "trackCount"
}

// MARK: - cell and storyboard identifier names
struct  Identifier{
    static let musicCell = "MusicCell"
    static let detailVC = "DetailViewController"
    static let albumDetailVC = "AlbumDetailViewController"
}

// MARK: - title of error
struct errTitle{
    static let save = "Data is not save"
    static let delete = "data is not deleted"
    static let filter = "data not filtered"
    static let bool = "condition not executed"
    static let getdata = "data is not get"
    static let exists = "data already exists"
    static let json = "Json error"
}

// MARK: - Predicate Names 
struct preName {
    static let musicID = "musicID = %d"
    static let artistName = "artistName contains[cd] %@"
}
