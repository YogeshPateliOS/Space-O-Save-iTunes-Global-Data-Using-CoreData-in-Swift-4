import Foundation
import UIKit
import CoreData
import SwiftyJSON

class DatabaseManaeger{
    
    
    static let sharedInstance = DatabaseManaeger()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    // MARK: - Data Save
    func save(json:[String:JSON])
    {
        do{
            if someEntityExists(id: (json[MusicField.artistId]?.int)!){
                print(errTitle.exists)
            }else{
                let musicName = NSEntityDescription.insertNewObject(forEntityName: MusicField.music, into: context) as! Music
                musicName.trackCensoredName = json[MusicField.trackCensoredName]?.stringValue
                musicName.artistName = json[MusicField.artistName]?.stringValue
                musicName.releaseDate = json[MusicField.releaseDate]?.stringValue
                musicName.trackPrice = json[MusicField.trackPrice]?.stringValue
                musicName.artworkUrl100 = json[MusicField.artworkUrl100]?.stringValue
                musicName.musicID = json[MusicField.artistId]?.stringValue
                musicName.collectionName = json[MusicField.collectionName]?.stringValue
                musicName.primaryGenreName = json[MusicField.primaryGenreName]?.stringValue
                musicName.country = json[MusicField.country]?.stringValue
                musicName.trackCount = json[MusicField.trackCount]?.stringValue
                try context.save()
            }
        }catch {
            print(errTitle.save)
        }
    }
   
    // MARK: - ID exists Avoid Repeation data
    func someEntityExists(id: Int) -> Bool {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: MusicField.music)
        fetchRequest.predicate = NSPredicate(format: preName.musicID, id)
        var results: [Music] = []
        do {
            results = try context.fetch(fetchRequest) as! [Music]
        }
        catch {
            print(errTitle.bool)
        }
        return results.count > 0
    }
    
    // MARK: - GetMusic Data
    func getAllData() -> [Music]{
        var music:[Music] = []
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: MusicField.music)
        do{
            music = try context.fetch(fetchRequest) as! [Music]
        }catch {
            print(errTitle.getdata)
        }
        return music
    }
    
    // MARK: - Filter Music Data
    func filterMusicData(name:String) -> [Music]{
        var music:[Music] = []
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: MusicField.music)
        if name.count > 0{
            let namePredicate = NSPredicate(format: preName.artistName,name)
            fetchRequest.predicate = namePredicate
        }
        do{
            music = try context.fetch(fetchRequest) as! [Music]
            print(music)
        }catch{
            print(errTitle.filter)
        }
        return music
    }
}

